---
type: resource
status: frozen
version: 1
resource-category: core
has-thresholds: true
tags:
  - ideaverse/system/resource
---

# THỂ LỰC

## 1. Định Nghĩa

> Tài Nguyên biểu diễn khả năng duy trì hoạt động thể chất hiện tại của cá thể.

```text
Thể Lực: hiện tại / Thể Lực Tối Đa
```

Chỉ Số liên quan:

- `Thể Lực Tối Đa`;
- `Hồi Phục Thể Lực`;
- `Tỷ Lệ Hồi Phục Thể Lực`.

Thể Lực có thể bị tiêu hao bởi vận động, chiến đấu, Kỹ Năng hoặc mechanic khác. Điều kiện/tốc độ hồi phục không bắt buộc giống nhau giữa mọi cá thể.

## 2. Phụ Tố Nội Sinh

Phụ Tố duy nhất của Thể Lực là:

> **Suy Kiệt Thể Lực**

| Thể Lực còn lại | Cường Độ Nội Bộ | Cấp |
|---:|---:|---:|
| `> 70%` | `0` | Không có |
| `(50%, 70%]` | `100` | I |
| `(30%, 50%]` | `200` | II |
| `(10%, 30%]` | `400` | IV |
| `(5%, 10%]` | `600` | VI |
| `(1%, 5%]` | `800` | VIII |
| `(0%, 1%]` | `1000` | X |

`Suy Kiệt Thể Lực` là Phụ Tố Nội Sinh Duy Trì Theo Điều Kiện: không phá Định Tính, không có duration, không stack nhiều bậc và cập nhật ngay khi tỷ lệ thay đổi.

## 3. Trạng Thái 0%

Khi `Thể Lực = 0`:

- không thể khởi tạo hành động yêu cầu tiêu hao Thể Lực;
- hành động/Kỹ Năng cần duy trì Thể Lực không thể tiếp tục khi không đủ chi phí duy trì;
- hành động không sử dụng Thể Lực vẫn có thể thực hiện nếu các điều kiện khác cho phép.

`0%` là state transition, không phải một Cấp Phụ Tố mới.
