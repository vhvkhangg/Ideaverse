---
type: resource
status: frozen
version: 1
resource-category: core
has-thresholds: true
tags:
  - ideaverse/system/resource
---

# SINH MỆNH LỰC

## 1. Định Nghĩa

> Tài Nguyên biểu diễn trạng thái sinh mệnh hiện tại của cá thể.

```text
Sinh Mệnh Lực: hiện tại / Sinh Mệnh Lực Tối Đa
```

Chỉ Số liên quan:

- `Sinh Mệnh Lực Tối Đa`;
- `Hồi Phục Sinh Mệnh Lực`;
- `Tỷ Lệ Hồi Phục Sinh Mệnh Lực`.

Giá trị tối đa/hồi phục có thể chịu ảnh hưởng từ Thuộc Tính, Công Pháp, Nghề Nghiệp, Thiên Phú, Trang Bị, Kỹ Năng hoặc mechanic khác; không có công thức universal bắt buộc.

## 2. Phụ Tố Nội Sinh

Phụ Tố duy nhất của Sinh Mệnh Lực là:

> **Suy Nhược Sinh Mệnh**

Cường Độ được tính động theo tỷ lệ Sinh Mệnh Lực:

| Sinh Mệnh Lực còn lại | Cường Độ Nội Bộ | Cấp |
|---:|---:|---:|
| `> 70%` | `0` | Không có |
| `(50%, 70%]` | `100` | I |
| `(30%, 50%]` | `200` | II |
| `(10%, 30%]` | `400` | IV |
| `(5%, 10%]` | `600` | VI |
| `(1%, 5%]` | `800` | VIII |
| `(0%, 1%]` | `1000` | X |

`Suy Nhược Sinh Mệnh` là Phụ Tố Nội Sinh Duy Trì Theo Điều Kiện: không phá Định Tính, không có duration, không stack nhiều bậc và cập nhật ngay khi tỷ lệ thay đổi.

## 3. Trạng Thái 0%

```text
Sinh Mệnh Lực = 0
→ kích hoạt cơ chế Tử Vong
```

Đây là state transition, không phải `Suy Nhược Sinh Mệnh` cấp cao hơn X.

Các mechanic như Bất Tử, Hồi Sinh, mạng phụ hoặc điều kiện tử vong thay thế có thể can thiệp nếu ghi rõ.

## 4. Ghi Chú

`Sinh Mệnh Tối Đa` trong thiết kế cũ đã được chuẩn hóa thành **`Sinh Mệnh Lực Tối Đa`**.
