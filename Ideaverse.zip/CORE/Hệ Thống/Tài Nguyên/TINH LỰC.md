---
type: resource
status: frozen
version: 1
resource-category: core
has-thresholds: true
tags:
  - ideaverse/system/resource
---

# TINH LỰC

## 1. Định Nghĩa

> Tài Nguyên biểu diễn khả năng duy trì hoạt động tinh thần hiện tại của cá thể.

```text
Tinh Lực: hiện tại / Tinh Lực Tối Đa
```

Chỉ Số liên quan:

- `Tinh Lực Tối Đa`;
- `Hồi Phục Tinh Lực`;
- `Tỷ Lệ Hồi Phục Tinh Lực`.

`Tinh Lực` không đồng nhất với Thuộc Tính [[Tinh Thần]]. `Tinh Thần` là năng lực nền của cá thể; `Tinh Lực` là pool trạng thái có thể tiêu hao và hồi phục.

## 2. Phụ Tố Nội Sinh

Phụ Tố duy nhất của Tinh Lực là:

> **Suy Kiệt Tinh Lực**

| Tinh Lực còn lại | Cường Độ Nội Bộ | Cấp |
|---:|---:|---:|
| `> 70%` | `0` | Không có |
| `(50%, 70%]` | `100` | I |
| `(30%, 50%]` | `200` | II |
| `(10%, 30%]` | `400` | IV |
| `(5%, 10%]` | `600` | VI |
| `(1%, 5%]` | `800` | VIII |
| `(0%, 1%]` | `1000` | X |

`Suy Kiệt Tinh Lực` là Phụ Tố Nội Sinh Duy Trì Theo Điều Kiện: không phá Định Tính, không có duration, không stack nhiều bậc và cập nhật ngay khi tỷ lệ thay đổi.

## 3. Trạng Thái 0%

Khi `Tinh Lực = 0`:

- không thể khởi tạo Kỹ Năng/tác vụ yêu cầu tiêu hao Tinh Lực;
- không thể tiếp tục Kỹ Năng/tác vụ cần duy trì Tinh Lực khi không đủ chi phí duy trì;
- không mặc định cá thể lập tức bất tỉnh hoặc hôn mê; trạng thái đó phải đến từ Phụ Tố hoặc mechanic cụ thể.

`0%` là state transition, không phải một Cấp Phụ Tố mới.
