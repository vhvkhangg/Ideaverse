---
type: attribute
category: special
growth-type: special
allow-negative-base: true
allow-negative-effective: true
extraction: false
tags:
  - ideaverse/system/attribute
---

# Vận Khí

## Định Nghĩa

> Mức độ thiên lệch thuận lợi hoặc bất lợi của cá thể trong những sự kiện vốn có yếu tố xác suất.

## Quy Tắc Cốt Lõi

> Vận Khí chỉ tác động tới **khả năng vốn đã tồn tại**. Nó không tự tạo ra kết quả bất khả thi hoặc biến xác suất `0` thành xác suất dương.

Ví dụ:

- Vật phẩm có xác suất rơi `> 0` → Vận Khí có thể ảnh hưởng.
- Vật phẩm không nằm trong tập kết quả có thể xảy ra → Vận Khí không tự sinh ra nó.

## Giá Trị

- `1` là mốc cực hạn tự nhiên của người thường đối với Vận Khí thuận lợi.
- Không có hard cap ở phía dương hoặc âm.
- `> 0`: thiên hướng thuận lợi.
- `= 0`: trung tính.
- `< 0`: thiên hướng bất lợi.

Giá trị Vận Khí không tự xác định một công thức xác suất toàn cục. Mỗi subsystem sử dụng Vận Khí phải định nghĩa cách điều chỉnh trọng số/xác suất của chính nó.

## Cách Sử Dụng

Vận Khí mặc định **không sinh Chỉ Số chiến đấu trực tiếp** và không tạo kết quả có xác suất `0`.

## Tăng Trưởng

Chỉ thay đổi bằng phương thức đặc biệt/hiếm như cơ duyên, quyền năng, nguyền rủa, cướp đoạt hoặc mechanic tương đương. Không nhận Điểm Thuộc Tính Tự Do thông thường.

## Modifier

Effective tuân theo convention Base → Flat → Percentage multiplicative trong [[THUỘC TÍNH]].

## Chiết Xuất

Không.
