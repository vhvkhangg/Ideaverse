---
type: attribute
category: special
growth-type: special
allow-negative-base: true
allow-negative-effective: true
extraction: false
tags:
  - ideaverse/system/attribute
---

# Mị Lực

## Định Nghĩa

> Khả năng khiến cá thể tạo ra sức hấp dẫn, chú ý hoặc thiện cảm lên sinh vật có nhận thức.

## Bản Chất

### Đại Diện Cho

- Sức hấp dẫn tổng hợp từ ngoại hình, khí chất, huyết mạch, thần tính, phong thái hoặc yếu tố tương tự.
- Mức độ dễ tạo ấn tượng tích cực khi chưa xét quan hệ và lịch sử xã hội cụ thể.

### Không Đại Diện Cho

- Nhan sắc đơn thuần.
- Danh Vọng hoặc mức độ nổi tiếng.
- Quan hệ cá nhân đã hình thành.
- Khả năng thuyết phục tuyệt đối.

## Giá Trị

- `1` là mốc cực hạn tự nhiên của người thường đối với Mị Lực.
- Không có hard cap ở phía dương hoặc âm.
- Base và Effective có thể âm.

Mị Lực âm biểu thị xu hướng gây khó chịu, bài xích, sợ hãi hoặc khiến sinh vật có nhận thức muốn giữ khoảng cách. Nó **không đồng nghĩa** ngoại hình xấu.

## Cách Sử Dụng

Mị Lực mặc định **không sinh Chỉ Số chiến đấu trực tiếp**. Subsystem xã hội, ấn tượng hoặc mechanic cụ thể quyết định cách sử dụng nó.

## Tăng Trưởng

Chỉ thay đổi bằng phương thức đặc biệt/hiếm hoặc biến đổi liên quan trực tiếp tới bản chất Mị Lực. Không nhận Điểm Thuộc Tính Tự Do thông thường.

## Modifier

Effective tuân theo convention Base → Flat → Percentage multiplicative trong [[THUỘC TÍNH]].

## Chiết Xuất

Không.
