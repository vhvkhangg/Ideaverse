---
type: attribute
category: special
growth-type: special
allow-negative-base: false
allow-negative-effective: true
extraction: false
tags:
  - ideaverse/system/attribute
---

# Ngộ Tính

## Định Nghĩa

> Khả năng lý giải, lĩnh ngộ, suy diễn và chuyển hóa tri thức thành hiểu biết hoặc năng lực thực tế.

## Bản Chất

### Đại Diện Cho

- Tốc độ và chiều sâu học tập.
- Khả năng lĩnh ngộ Công Pháp, Kỹ Năng, Ma Pháp, Khoa Học, Hắc Khoa Kỹ và các hệ tri thức khác.
- Khả năng suy diễn, cải tiến hoặc kết nối tri thức khi cơ chế tương ứng cho phép.

### Không Đại Diện Cho

- Lượng kiến thức đã biết.
- Cường độ tinh thần — thuộc [[Tinh Thần]].
- Trí nhớ hoặc IQ nếu các khái niệm đó được mô hình hóa riêng.

## Giá Trị

- `1` là mốc cực hạn tự nhiên của người thường đối với Ngộ Tính.
- Không có hard cap.
- Base luôn `>= 0`.
- Modifier có thể làm Effective `< 0`.

Effective âm biểu thị trạng thái bất lợi vượt qua mốc `0`; hậu quả cụ thể do mechanic gây ra nó quy định.

## Cách Sử Dụng

Ngộ Tính mặc định **không chuyển trực tiếp thành Chỉ Số chiến đấu**. Các subsystem học tập/lĩnh ngộ/cải tiến sử dụng giá trị này để thực hiện check, hệ số hoặc công thức riêng.

## Tăng Trưởng

Chỉ thay đổi bằng phương thức đặc biệt/hiếm hoặc mechanic ghi rõ ngoại lệ. Không nhận Điểm Thuộc Tính Tự Do thông thường.

## Modifier

Effective tuân theo convention Base → Flat → Percentage multiplicative trong [[THUỘC TÍNH]], nhưng không áp sàn `0` cho Effective.

## Chiết Xuất

Không.
