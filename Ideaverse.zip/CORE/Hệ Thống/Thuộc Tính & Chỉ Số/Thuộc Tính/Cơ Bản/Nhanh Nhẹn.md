---
type: attribute
category: basic
growth-type: ordinary
allow-negative-base: false
allow-negative-effective: false
extraction: true
tags:
  - ideaverse/system/attribute
---

# Nhanh Nhẹn

## Định Nghĩa

> Khả năng điều khiển cơ thể với tốc độ, độ chính xác và phản ứng cao.

## Bản Chất

### Đại Diện Cho

- Phản xạ.
- Tốc độ động tác và đổi hướng.
- Phối hợp và độ chính xác của vận động cơ thể.

### Không Đại Diện Cho

- Tốc độ do phương tiện, cơ giáp hoặc thiết bị tạo ra nếu không phụ thuộc khả năng vận động của cá thể.
- Dịch chuyển tức thời hoặc năng lực không dựa trên vận động cơ thể.
- Sức Mạnh cơ bắp.

## Thang Giá Trị

- `~0.5`: tham chiếu người trưởng thành khỏe mạnh bình thường.
- `1`: cực hạn tự nhiên của người thường.
- `>1`: vượt cực hạn người thường.
- Chủng tộc khác có thể có Base `>1` tự nhiên.
- Không có hard cap.

## Quan Hệ Với Chỉ Số

Nhanh Nhẹn thường đóng góp vào:

- Tốc Độ Đánh;
- Tốc Độ Di Chuyển;
- Chính Xác;
- Né Tránh;
- các đại lượng vận động khác nếu subsystem quy định.

Không có conversion cố định toàn cục; hệ số phụ thuộc build và subsystem.

## Tăng Trưởng

Là Thuộc Tính Cơ Bản, có thể tăng Base bằng tăng trưởng thông thường theo [[THUỘC TÍNH]].

## Modifier

Effective tuân theo công thức multiplicative chung trong [[THUỘC TÍNH]]. Effective cuối cùng không thấp hơn `0`.

## Chiết Xuất

Có. Tuân theo 10 Chuyển, Thí Luyện và Hệ Số Chiết Xuất Tích Lũy trong [[THUỘC TÍNH]].
