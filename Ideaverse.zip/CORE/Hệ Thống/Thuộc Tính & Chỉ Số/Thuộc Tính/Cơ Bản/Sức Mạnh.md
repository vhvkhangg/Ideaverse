---
type: attribute
category: basic
growth-type: ordinary
allow-negative-base: false
allow-negative-effective: false
extraction: true
tags:
  - ideaverse/system/attribute
---

# Sức Mạnh

## Định Nghĩa

> Khả năng tạo ra lực vật lý chủ động của cơ thể.

## Bản Chất

### Đại Diện Cho

- Lực đánh, kéo, đẩy, nâng và mang vác.
- Khả năng phát lực trực tiếp bằng cơ thể.

### Không Đại Diện Cho

- Độ bền và khả năng chịu thương của cơ thể — thuộc [[Thể Chất]].
- Tốc độ phản ứng hoặc điều khiển cơ thể — thuộc [[Nhanh Nhẹn]].
- Kỹ thuật chiến đấu.

## Thang Giá Trị

- `~0.5`: tham chiếu người trưởng thành khỏe mạnh bình thường.
- `1`: cực hạn tự nhiên của người thường.
- `>1`: vượt cực hạn người thường.
- Chủng tộc khác có thể có Base `>1` ngay từ khi trưởng thành hoặc khi sinh ra nếu lore cho phép.
- Không có hard cap.

## Quan Hệ Với Chỉ Số/Tài Nguyên

Sức Mạnh thường đóng góp vào:

- [[CHỈ SỐ CƠ SỞ|Công Vật Lý]];
- khả năng phát lực;
- một phần Thể Lực hoặc Chỉ Số vật lý khác nếu build/subsystem quy định.

Không có conversion cố định toàn cục. Hệ số do Chủng Tộc, Nghề Nghiệp, Công Pháp, Huyết Mạch, Thiên Phú hoặc hệ thống sức mạnh tương ứng quyết định.

## Tăng Trưởng

Là Thuộc Tính Cơ Bản, có thể tăng Base bằng tăng trưởng thông thường theo [[THUỘC TÍNH]], gồm Điểm Thuộc Tính Tự Do, rèn luyện và các nguồn vĩnh viễn hợp lệ.

## Modifier

Effective tuân theo công thức multiplicative chung trong [[THUỘC TÍNH]]. Effective cuối cùng không thấp hơn `0`.

## Chiết Xuất

Có. Tuân theo 10 Chuyển, Thí Luyện và Hệ Số Chiết Xuất Tích Lũy trong [[THUỘC TÍNH]].
