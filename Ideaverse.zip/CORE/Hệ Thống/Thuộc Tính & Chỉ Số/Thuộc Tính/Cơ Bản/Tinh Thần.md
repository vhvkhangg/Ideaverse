---
type: attribute
category: basic
growth-type: ordinary
allow-negative-base: false
allow-negative-effective: false
extraction: true
tags:
  - ideaverse/system/attribute
---

# Tinh Thần

## Định Nghĩa

> Cường độ, độ ổn định và khả năng vận hành của ý thức/tinh thần.

## Bản Chất

### Đại Diện Cho

- Khả năng tập trung và chịu tải tinh thần.
- Khả năng vận hành nhiều tác vụ tinh thần đồng thời.
- Nền tảng cho cảm nhận, điều khiển Năng Lượng hoặc kháng tác động tinh thần khi subsystem tương ứng sử dụng nó.

### Không Đại Diện Cho

- Trí thông minh nói chung.
- Khả năng học và lĩnh ngộ — thuộc [[Ngộ Tính]].
- Kiến thức mà cá thể đã tích lũy.

## Thang Giá Trị

- `~0.5`: tham chiếu người trưởng thành khỏe mạnh bình thường.
- `1`: cực hạn tự nhiên của người thường.
- `>1`: vượt cực hạn người thường.
- Chủng tộc khác có thể có Base `>1` tự nhiên.
- Không có hard cap.

## Quan Hệ Với Chỉ Số/Tài Nguyên

Tinh Thần thường đóng góp vào:

- Tinh Lực Tối Đa;
- các loại [[NĂNG LƯỢNG]] phù hợp;
- Công Pháp Thuật trong hệ thống phù hợp;
- các Chỉ Số/tác vụ tinh thần nếu subsystem quy định.

Không phải mọi loại Năng Lượng đều bắt buộc scale từ Tinh Thần. Hệ số và quan hệ cụ thể do Công Pháp, Nghề Nghiệp, Chủng Tộc, Huyết Mạch, Thiên Phú hoặc power system sở hữu.

## Tăng Trưởng

Là Thuộc Tính Cơ Bản, có thể tăng Base bằng tăng trưởng thông thường theo [[THUỘC TÍNH]].

## Modifier

Effective tuân theo công thức multiplicative chung trong [[THUỘC TÍNH]]. Effective cuối cùng không thấp hơn `0`.

## Chiết Xuất

Có. Tuân theo 10 Chuyển, Thí Luyện và Hệ Số Chiết Xuất Tích Lũy trong [[THUỘC TÍNH]].
