---
type: attribute
category: basic
growth-type: ordinary
allow-negative-base: false
allow-negative-effective: false
extraction: true
tags:
  - ideaverse/system/attribute
---

# Thể Chất

## Định Nghĩa

> Chất lượng tổng thể, sức chịu đựng và khả năng duy trì hoạt động của cơ thể.

## Bản Chất

### Đại Diện Cho

- Sức bền và khả năng chịu tải cơ thể.
- Khả năng chịu thương và phục hồi tự nhiên.
- Khả năng thích nghi với áp lực thể chất và môi trường.

### Không Đại Diện Cho

- Sức Mạnh cơ bắp thuần túy — thuộc [[Sức Mạnh]].
- Giá trị Sinh Mệnh Lực hiện tại — thuộc [[SINH MỆNH LỰC]].

## Thang Giá Trị

- `~0.5`: tham chiếu người trưởng thành khỏe mạnh bình thường.
- `1`: cực hạn tự nhiên của người thường.
- `>1`: vượt cực hạn người thường.
- Chủng tộc khác có thể có Base `>1` tự nhiên.
- Không có hard cap.

## Quan Hệ Với Chỉ Số/Tài Nguyên

Thể Chất thường đóng góp vào:

- [[CHỈ SỐ CƠ SỞ|Sinh Mệnh Lực Tối Đa]];
- Thể Lực Tối Đa;
- hồi phục thể chất;
- độ bền cơ thể và các Chỉ Số liên quan nếu subsystem quy định.

Không có conversion cố định toàn cục; hệ số phụ thuộc build và subsystem.

## Tăng Trưởng

Là Thuộc Tính Cơ Bản, có thể tăng Base bằng tăng trưởng thông thường theo [[THUỘC TÍNH]].

## Modifier

Effective tuân theo công thức multiplicative chung trong [[THUỘC TÍNH]]. Effective cuối cùng không thấp hơn `0`.

## Chiết Xuất

Có. Tuân theo 10 Chuyển, Thí Luyện và Hệ Số Chiết Xuất Tích Lũy trong [[THUỘC TÍNH]].
