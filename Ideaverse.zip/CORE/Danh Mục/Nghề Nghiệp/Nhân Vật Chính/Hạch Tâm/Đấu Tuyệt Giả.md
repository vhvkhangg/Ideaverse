Đặc Tính:
1.  